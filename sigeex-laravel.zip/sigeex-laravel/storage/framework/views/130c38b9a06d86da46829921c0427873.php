<?php $__env->startSection('title', 'RH - Solicitações de Servidores'); ?>
<?php $__env->startSection('header', 'Solicitações de Novos Servidores'); ?>

<?php $__env->startSection('sidebar'); ?>
    <a href="/rh" class="nav-link"><i class="bi bi-speedometer2"></i> Dashboard</a>
    <a href="/rh/escalas" class="nav-link"><i class="bi bi-calendar-check"></i> Escalas</a>
    <a href="/rh/servidores" class="nav-link"><i class="bi bi-people"></i> Servidores</a>
    <a href="/rh/relatorios" class="nav-link"><i class="bi bi-file-earmark-bar-graph"></i> Relatórios</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php if(session('success')): ?>
<div class="alert alert-success alert-dismissible fade show" role="alert">
    <?php echo e(session('success')); ?>

    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
</div>
<?php endif; ?>

<?php if(session('error')): ?>
<div class="alert alert-danger alert-dismissible fade show" role="alert">
    <?php echo e(session('error')); ?>

    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
</div>
<?php endif; ?>

<div class="mb-3">
    <a href="/rh/servidores" class="btn btn-outline-secondary">
        <i class="bi bi-arrow-left"></i> Voltar para Servidores
    </a>
</div>

<div class="card border-0 shadow-sm">
    <div class="card-header bg-white py-3">
        <h5 class="mb-0 fw-semibold"><i class="bi bi-person-plus me-2 text-primary"></i>Solicitações de Inclusão de Servidores</h5>
    </div>
    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
            <thead class="table-light">
                <tr>
                    <th>Data</th>
                    <th>Matrícula</th>
                    <th>Nome</th>
                    <th>Unidade</th>
                    <th>Cargo</th>
                    <th>Solicitante</th>
                    <th class="text-center">Status</th>
                    <th class="text-center">Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $solicitacoes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <?php
                    $statusClass = match($s->status) {
                        'pendente' => 'bg-warning text-dark',
                        'aprovada' => 'bg-success',
                        'rejeitada' => 'bg-danger',
                        default => 'bg-secondary'
                    };
                ?>
                <tr>
                    <td><?php echo e($s->created_at->format('d/m/Y H:i')); ?></td>
                    <td><strong><?php echo e($s->matricula); ?></strong></td>
                    <td><?php echo e($s->nome); ?></td>
                    <td><?php echo e($s->unidade->nome ?? '-'); ?></td>
                    <td><?php echo e($s->cargo ?? '-'); ?></td>
                    <td><?php echo e($s->solicitante->nome ?? '-'); ?></td>
                    <td class="text-center">
                        <span class="badge <?php echo e($statusClass); ?>"><?php echo e(ucfirst($s->status)); ?></span>
                    </td>
                    <td class="text-center">
                        <?php if($s->status === 'pendente'): ?>
                        <button type="button" class="btn btn-sm btn-success" data-bs-toggle="modal" data-bs-target="#aprovarModal<?php echo e($s->id); ?>">
                            <i class="bi bi-check-lg"></i> Habilitar
                        </button>
                        <button type="button" class="btn btn-sm btn-danger" data-bs-toggle="modal" data-bs-target="#rejeitarModal<?php echo e($s->id); ?>">
                            <i class="bi bi-x-lg"></i> Rejeitar
                        </button>
                        <?php elseif($s->status === 'rejeitada'): ?>
                        <span class="text-muted small" title="<?php echo e($s->motivo_rejeicao); ?>">
                            <i class="bi bi-info-circle"></i> <?php echo e(Str::limit($s->motivo_rejeicao, 30)); ?>

                        </span>
                        <?php else: ?>
                        <span class="text-success"><i class="bi bi-check-circle"></i> Aprovado</span>
                        <?php endif; ?>
                    </td>
                </tr>

                <!-- Modal Aprovar -->
                <div class="modal fade" id="aprovarModal<?php echo e($s->id); ?>" tabindex="-1">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header bg-success text-white">
                                <h5 class="modal-title"><i class="bi bi-check-circle me-2"></i>Habilitar Servidor</h5>
                                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                            </div>
                            <form action="/rh/aprovar-solicitacao-servidor" method="POST">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="solicitacao_id" value="<?php echo e($s->id); ?>">
                                <div class="modal-body">
                                    <p>Deseja habilitar o servidor abaixo?</p>
                                    <ul class="list-unstyled">
                                        <li><strong>Matrícula:</strong> <?php echo e($s->matricula); ?></li>
                                        <li><strong>Nome:</strong> <?php echo e($s->nome); ?></li>
                                        <li><strong>Unidade:</strong> <?php echo e($s->unidade->nome ?? '-'); ?></li>
                                        <li><strong>Cargo:</strong> <?php echo e($s->cargo ?? '-'); ?></li>
                                    </ul>
                                    <div class="alert alert-info mb-0">
                                        <i class="bi bi-info-circle"></i> O servidor será cadastrado como ATIVO e APTO para escala extra.
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                                    <button type="submit" class="btn btn-success">
                                        <i class="bi bi-check-lg"></i> Habilitar Servidor
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>

                <!-- Modal Rejeitar -->
                <div class="modal fade" id="rejeitarModal<?php echo e($s->id); ?>" tabindex="-1">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header bg-danger text-white">
                                <h5 class="modal-title"><i class="bi bi-x-circle me-2"></i>Rejeitar Solicitação</h5>
                                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                            </div>
                            <form action="/rh/rejeitar-solicitacao-servidor" method="POST">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="solicitacao_id" value="<?php echo e($s->id); ?>">
                                <div class="modal-body">
                                    <p>Rejeitar a solicitação de inclusão de <strong><?php echo e($s->nome); ?></strong>?</p>
                                    <div class="mb-3">
                                        <label class="form-label">Motivo da Rejeição <span class="text-danger">*</span></label>
                                        <textarea name="motivo_rejeicao" class="form-control" rows="3" required minlength="5" placeholder="Informe o motivo da rejeição..."></textarea>
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                                    <button type="submit" class="btn btn-danger">
                                        <i class="bi bi-x-lg"></i> Rejeitar
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="8" class="text-center py-4 text-muted">
                        <i class="bi bi-inbox fs-1 d-block mb-2 opacity-50"></i>
                        Nenhuma solicitação encontrada
                    </td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/runner/workspace/sigeex-laravel/resources/views/rh/solicitacoes-servidores.blade.php ENDPATH**/ ?>