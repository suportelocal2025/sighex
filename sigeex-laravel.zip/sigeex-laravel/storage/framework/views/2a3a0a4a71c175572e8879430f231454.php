<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Escala - <?php echo e($unidade->nome ?? 'Unidade'); ?> - <?php echo e($meses[$mes]); ?>/<?php echo e($ano); ?></title>
    <style>
        @page { margin: 1.5cm; size: A4 portrait; }
        * { box-sizing: border-box; }
        body { 
            font-family: Arial, sans-serif; 
            font-size: 11pt; 
            line-height: 1.4;
            margin: 0;
            padding: 20px;
            color: #333;
        }
        .header {
            text-align: center;
            border-bottom: 2px solid #1a4480;
            padding-bottom: 15px;
            margin-bottom: 25px;
        }
        .header h1 {
            margin: 0 0 5px 0;
            font-size: 18pt;
            color: #1a4480;
        }
        .header h2 {
            margin: 0;
            font-size: 14pt;
            font-weight: normal;
            color: #666;
        }
        .grupo {
            margin-bottom: 25px;
            page-break-inside: avoid;
        }
        .grupo-header {
            background: #1a4480;
            color: white;
            padding: 8px 12px;
            font-weight: bold;
            font-size: 11pt;
            border-radius: 4px 4px 0 0;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin: 0;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 8px 10px;
            text-align: left;
        }
        th {
            background: #f5f5f5;
            font-weight: bold;
            font-size: 10pt;
        }
        td { font-size: 10pt; }
        .text-center { text-align: center; }
        .text-right { text-align: right; }
        .lider { color: #d4a00a; font-weight: bold; }
        .dias { font-family: monospace; font-size: 9pt; }
        .footer {
            margin-top: 30px;
            text-align: center;
            font-size: 9pt;
            color: #666;
            border-top: 1px solid #ddd;
            padding-top: 10px;
        }
        @media print {
            body { padding: 0; }
            .no-print { display: none; }
        }
    </style>
</head>
<body>
    <div class="no-print" style="text-align: center; margin-bottom: 20px;">
        <button onclick="window.print()" style="padding: 10px 30px; font-size: 14pt; cursor: pointer;">
            Imprimir / Salvar PDF
        </button>
    </div>
    
    <div class="header">
        <h1><?php echo e($unidade->nome ?? 'Unidade'); ?></h1>
        <h2>Escala Extraordinária - <?php echo e($meses[$mes]); ?>/<?php echo e($ano); ?></h2>
    </div>
    
    <?php if(empty($agrupado)): ?>
        <p style="text-align: center; color: #666;">Nenhuma alocação encontrada para esta escala.</p>
    <?php else: ?>
        <?php $__currentLoopData = $agrupado; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $grupo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="grupo">
            <div class="grupo-header">
                <?php echo e($grupo['modulo']); ?> - <?php echo e($grupo['equipe']); ?>

            </div>
            <table>
                <thead>
                    <tr>
                        <th style="width: 35%">Nome</th>
                        <th style="width: 15%">Matrícula</th>
                        <th style="width: 35%">Dias</th>
                        <th style="width: 15%" class="text-center">Total Horas</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $grupo['servidores']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $srv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>
                            <?php echo e($srv['nome']); ?>

                            <?php if($srv['is_lider']): ?>
                                <span class="lider">★</span>
                            <?php endif; ?>
                        </td>
                        <td><?php echo e($srv['matricula']); ?></td>
                        <td class="dias"><?php echo e(implode(', ', $srv['dias'])); ?></td>
                        <td class="text-center"><?php echo e(number_format($srv['horas'], 0)); ?>h</td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
    
    <div class="footer">
        Documento gerado em <?php echo e(date('d/m/Y H:i')); ?> - SIGEEX - Sistema de Gestão de Escalas Extraordinárias
    </div>
</body>
</html>
<?php /**PATH /home/runner/workspace/sigeex-laravel/resources/views/diretor/imprimir-mural.blade.php ENDPATH**/ ?>