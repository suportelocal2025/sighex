<?php $__env->startSection('title', 'Superintendente - Distribuição'); ?>
<?php $__env->startSection('header', 'Distribuição de Orçamento'); ?>

<?php $__env->startSection('sidebar'); ?>
    <a href="/superintendente" class="nav-link"><i class="bi bi-speedometer2"></i> Dashboard</a>
    <a href="/superintendente/orcamento" class="nav-link"><i class="bi bi-wallet2"></i> Orçamento</a>
    <a href="/superintendente/distribuicao" class="nav-link active"><i class="bi bi-diagram-3"></i> Distribuição</a>
    <a href="/superintendente/escalas" class="nav-link"><i class="bi bi-calendar-check"></i> Escalas</a>
    <a href="/superintendente/relatorios" class="nav-link"><i class="bi bi-file-earmark-bar-graph"></i> Relatórios</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row mb-4">
    <div class="col-md-4">
        <div class="card bg-primary text-white">
            <div class="card-body">
                <h6>Orçamento Total</h6>
                <h3>R$ <?php echo e(number_format($valorTotal, 2, ',', '.')); ?></h3>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card bg-warning text-dark">
            <div class="card-body">
                <h6>Reserva Técnica</h6>
                <h3>R$ <?php echo e(number_format($reservaTecnica, 2, ',', '.')); ?></h3>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card bg-success text-white">
            <div class="card-body">
                <h6>Disponível para Distribuir</h6>
                <h3>R$ <?php echo e(number_format($valorDisponivel, 2, ',', '.')); ?></h3>
            </div>
        </div>
    </div>
</div>

<div class="card">
    <div class="card-header bg-white">
        <h5 class="mb-0"><i class="bi bi-diagram-3 me-2"></i>Distribuição por Unidade - <?php echo e($ano); ?></h5>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>Unidade</th>
                        <th>Valor Distribuído</th>
                        <th>Margem Mensal</th>
                        <th>Valor Gasto</th>
                        <th>Saldo</th>
                        <th>Ações</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $unidades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unidade): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $dist = $distribuicoes->get($unidade->id);
                        $distribuido = $dist->valor_distribuido ?? 0;
                        $margem = $dist->margin_percentual ?? 10;
                        $gasto = $dist->valor_gasto ?? 0;
                        $saldo = $distribuido - $gasto;
                    ?>
                    <tr>
                        <td><?php echo e($unidade->nome); ?></td>
                        <td>R$ <?php echo e(number_format($distribuido, 2, ',', '.')); ?></td>
                        <td><span class="badge bg-info"><?php echo e(number_format($margem, 0)); ?>%</span></td>
                        <td>R$ <?php echo e(number_format($gasto, 2, ',', '.')); ?></td>
                        <td class="<?php echo e($saldo < 0 ? 'text-danger' : 'text-success'); ?>">
                            R$ <?php echo e(number_format($saldo, 2, ',', '.')); ?>

                        </td>
                        <td>
                            <button class="btn btn-sm btn-primary" data-bs-toggle="modal" data-bs-target="#modalDistribuir"
                                    onclick="abrirModal(<?php echo e($unidade->id); ?>, '<?php echo e($unidade->nome); ?>', <?php echo e($distribuido); ?>, <?php echo e($margem); ?>)">
                                <i class="bi bi-pencil"></i> Editar
                            </button>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<div class="modal fade" id="modalDistribuir" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="POST" action="/superintendente/distribuicao">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="unidade_id" id="modal_unidade_id">
                <div class="modal-header">
                    <h5 class="modal-title">Distribuir Orçamento</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <p>Unidade: <strong id="modal_unidade_nome"></strong></p>
                    <div class="mb-3">
                        <label class="form-label">Valor Anual a Distribuir (R$)</label>
                        <input type="number" name="valor" id="modal_valor" class="form-control" step="0.01" min="0" required>
                        <small class="text-muted">Este valor será dividido por 12 meses.</small>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Margem de Tolerância Mensal (%)</label>
                        <div class="input-group">
                            <input type="number" name="margin_percentual" id="modal_margem" class="form-control" step="1" min="0" max="100" value="10" required>
                            <span class="input-group-text">%</span>
                        </div>
                        <small class="text-muted">Se o diretor ultrapassar o valor mensal + margem, um alerta será gerado.</small>
                    </div>
                    <p class="text-muted small">Disponível: R$ <?php echo e(number_format($valorDisponivel, 2, ',', '.')); ?></p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                    <button type="submit" class="btn btn-primary">Salvar</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
function abrirModal(id, nome, valor, margem) {
    document.getElementById('modal_unidade_id').value = id;
    document.getElementById('modal_unidade_nome').textContent = nome;
    document.getElementById('modal_valor').value = valor;
    document.getElementById('modal_margem').value = margem || 10;
}
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/runner/workspace/sigeex-laravel/resources/views/superintendente/distribuicao.blade.php ENDPATH**/ ?>