<?php $__env->startSection('title', 'Superintendente - Escalas'); ?>
<?php $__env->startSection('header', 'Gestão de Escalas'); ?>

<?php $__env->startSection('sidebar'); ?>
    <a href="/superintendente" class="nav-link"><i class="bi bi-speedometer2"></i> Dashboard</a>
    <a href="/superintendente/orcamento" class="nav-link"><i class="bi bi-wallet2"></i> Orçamento</a>
    <a href="/superintendente/distribuicao" class="nav-link"><i class="bi bi-diagram-3"></i> Distribuição</a>
    <a href="/superintendente/escalas" class="nav-link active"><i class="bi bi-calendar-check"></i> Escalas</a>
    <a href="/superintendente/relatorios" class="nav-link"><i class="bi bi-file-earmark-bar-graph"></i> Relatórios</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header bg-white">
        <div class="row align-items-center">
            <div class="col">
                <h5 class="mb-0"><i class="bi bi-calendar-check me-2"></i>Escalas - <?php echo e($ano); ?></h5>
            </div>
            <div class="col-auto">
                <div class="btn-group">
                    <a href="/superintendente/escalas?status=todos" class="btn btn-sm <?php echo e($status === 'todos' ? 'btn-primary' : 'btn-outline-primary'); ?>">Todas</a>
                    <a href="/superintendente/escalas?status=pendente" class="btn btn-sm <?php echo e($status === 'pendente' ? 'btn-warning' : 'btn-outline-warning'); ?>">Pendentes</a>
                    <a href="/superintendente/escalas?status=aprovada" class="btn btn-sm <?php echo e($status === 'aprovada' ? 'btn-success' : 'btn-outline-success'); ?>">Aprovadas</a>
                    <a href="/superintendente/escalas?status=executada" class="btn btn-sm <?php echo e($status === 'executada' ? 'btn-info' : 'btn-outline-info'); ?>">Executadas</a>
                </div>
            </div>
        </div>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>Unidade</th>
                        <th>Mês/Ano</th>
                        <th>Status</th>
                        <th>Data Envio</th>
                        <th>Ações</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $escalas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $escala): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr class="<?php echo e($escala->excede_margem && $escala->status === 'pendente' ? 'table-danger' : ($escala->usa_margem ? 'table-warning' : '')); ?>">
                        <td>
                            <?php echo e($escala->unidade->nome ?? 'N/A'); ?>

                            <?php if($escala->excede_margem && $escala->status === 'pendente'): ?>
                                <span class="badge bg-danger ms-1"><i class="bi bi-exclamation-triangle"></i> Requer sua aprovação</span>
                            <?php elseif($escala->usa_margem): ?>
                                <span class="badge bg-warning text-dark ms-1"><i class="bi bi-info-circle"></i> Usa margem</span>
                            <?php endif; ?>
                        </td>
                        <td><?php echo e(str_pad($escala->mes, 2, '0', STR_PAD_LEFT)); ?>/<?php echo e($escala->ano); ?></td>
                        <td>
                            <?php switch($escala->status):
                                case ('pendente'): ?>
                                    <span class="badge bg-warning text-dark">Pendente</span>
                                    <?php break; ?>
                                <?php case ('aprovada'): ?>
                                    <span class="badge bg-success">Aprovada</span>
                                    <?php break; ?>
                                <?php case ('rejeitada'): ?>
                                    <span class="badge bg-danger">Rejeitada</span>
                                    <?php break; ?>
                                <?php case ('executada'): ?>
                                    <span class="badge bg-info">Executada</span>
                                    <?php break; ?>
                            <?php endswitch; ?>
                        </td>
                        <td><?php echo e($escala->data_envio ? \Carbon\Carbon::parse($escala->data_envio)->format('d/m/Y H:i') : '-'); ?></td>
                        <td>
                            <a href="/superintendente/escala/<?php echo e($escala->id); ?>" class="btn btn-sm btn-outline-primary">
                                <i class="bi bi-eye"></i> Detalhar
                            </a>
                            <?php if($escala->excede_margem && $escala->status === 'pendente'): ?>
                                <form method="POST" action="/superintendente/aprovar-escala" class="d-inline">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="escala_id" value="<?php echo e($escala->id); ?>">
                                    <button type="submit" class="btn btn-sm btn-success" onclick="return confirm('Aprovar escala que excede a margem orçamentária?')">
                                        <i class="bi bi-check-lg"></i> Aprovar
                                    </button>
                                </form>
                                <button type="button" class="btn btn-sm btn-danger" data-bs-toggle="modal" data-bs-target="#rejectModal<?php echo e($escala->id); ?>">
                                    <i class="bi bi-x-lg"></i> Rejeitar
                                </button>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php if($escala->excede_margem && $escala->status === 'pendente'): ?>
                    <tr class="table-light">
                        <td colspan="5" class="small">
                            <i class="bi bi-info-circle text-danger"></i>
                            <strong>Orçamento do mês:</strong> R$ <?php echo e(number_format($escala->orcamento_mes, 2, ',', '.')); ?> |
                            <strong>Limite com margem:</strong> R$ <?php echo e(number_format($escala->limite_margem, 2, ',', '.')); ?> |
                            <strong>Valor previsto:</strong> <span class="text-danger fw-bold">R$ <?php echo e(number_format($escala->valor_previsto, 2, ',', '.')); ?></span>
                        </td>
                    </tr>
                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="5" class="text-center text-muted">Nenhuma escala encontrada</td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php $__currentLoopData = $escalas->where('excede_margem', true)->where('status', 'pendente'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $escala): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="modal fade" id="rejectModal<?php echo e($escala->id); ?>" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="POST" action="/superintendente/rejeitar-escala">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="escala_id" value="<?php echo e($escala->id); ?>">
                <div class="modal-header">
                    <h5 class="modal-title">Rejeitar Escala</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <p><strong>Unidade:</strong> <?php echo e($escala->unidade->nome); ?></p>
                    <p><strong>Período:</strong> <?php echo e(str_pad($escala->mes, 2, '0', STR_PAD_LEFT)); ?>/<?php echo e($escala->ano); ?></p>
                    <div class="mb-3">
                        <label class="form-label">Motivo da rejeição *</label>
                        <textarea name="motivo_rejeicao" class="form-control" rows="3" required minlength="10" placeholder="Informe o motivo da rejeição (mínimo 10 caracteres)"></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                    <button type="submit" class="btn btn-danger">Rejeitar Escala</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/runner/workspace/sigeex-laravel/resources/views/superintendente/escalas.blade.php ENDPATH**/ ?>