<?php $__env->startSection('title', 'Superintendente - Relatório Financeiro'); ?>
<?php $__env->startSection('header', 'Relatório Financeiro'); ?>

<?php $__env->startSection('sidebar'); ?>
    <a href="/superintendente" class="nav-link"><i class="bi bi-speedometer2"></i> Dashboard</a>
    <a href="/superintendente/orcamento" class="nav-link"><i class="bi bi-wallet2"></i> Orçamento</a>
    <a href="/superintendente/distribuicao" class="nav-link"><i class="bi bi-diagram-3"></i> Distribuição</a>
    <a href="/superintendente/escalas" class="nav-link"><i class="bi bi-calendar-check"></i> Escalas</a>
    <a href="/superintendente/relatorios" class="nav-link active"><i class="bi bi-file-earmark-bar-graph"></i> Relatórios</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="card mb-4">
    <div class="card-header d-flex justify-content-between align-items-center">
        <span><i class="bi bi-funnel me-2"></i>Filtros do Relatório</span>
        <a href="/superintendente/relatorios" class="btn btn-outline-secondary btn-sm">
            <i class="bi bi-arrow-left me-1"></i> Voltar
        </a>
    </div>
    <div class="card-body">
        <form method="GET" action="/superintendente/relatorio-financeiro" class="row g-3 align-items-end">
            <div class="col-md-2">
                <label class="form-label small">Ano</label>
                <select name="ano" class="form-select form-select-sm">
                    <?php for($i = date('Y'); $i >= date('Y') - 5; $i--): ?>
                        <option value="<?php echo e($i); ?>" <?php echo e($ano == $i ? 'selected' : ''); ?>><?php echo e($i); ?></option>
                    <?php endfor; ?>
                </select>
            </div>
            <div class="col-md-2">
                <label class="form-label small">Mês Início</label>
                <select name="mes_inicio" class="form-select form-select-sm">
                    <?php $mesesNomes = ['', 'Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho', 'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro']; ?>
                    <?php for($i = 1; $i <= 12; $i++): ?>
                        <option value="<?php echo e($i); ?>" <?php echo e($mesInicio == $i ? 'selected' : ''); ?>><?php echo e($mesesNomes[$i]); ?></option>
                    <?php endfor; ?>
                </select>
            </div>
            <div class="col-md-2">
                <label class="form-label small">Mês Fim</label>
                <select name="mes_fim" class="form-select form-select-sm">
                    <?php for($i = 1; $i <= 12; $i++): ?>
                        <option value="<?php echo e($i); ?>" <?php echo e($mesFim == $i ? 'selected' : ''); ?>><?php echo e($mesesNomes[$i]); ?></option>
                    <?php endfor; ?>
                </select>
            </div>
            <div class="col-md-3">
                <label class="form-label small">Unidade</label>
                <select name="unidade_id" class="form-select form-select-sm">
                    <option value="">Todas as Unidades</option>
                    <?php $__currentLoopData = $unidades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unidade): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($unidade->id); ?>" <?php echo e($unidadeId == $unidade->id ? 'selected' : ''); ?>><?php echo e($unidade->nome); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="col-md-3 d-flex gap-2">
                <button type="submit" class="btn btn-primary btn-sm flex-grow-1">
                    <i class="bi bi-funnel me-1"></i> Filtrar
                </button>
                <a href="/superintendente/relatorio-financeiro/exportar-excel?ano=<?php echo e($ano); ?>&mes_inicio=<?php echo e($mesInicio); ?>&mes_fim=<?php echo e($mesFim); ?>&unidade_id=<?php echo e($unidadeId); ?>" class="btn btn-success btn-sm" title="Exportar Excel">
                    <i class="bi bi-file-earmark-excel"></i>
                </a>
                <button type="button" onclick="window.print()" class="btn btn-secondary btn-sm" title="Imprimir/PDF">
                    <i class="bi bi-printer"></i>
                </button>
            </div>
        </form>
    </div>
</div>

<?php if(session('error')): ?>
    <div class="alert alert-danger alert-dismissible fade show">
        <?php echo e(session('error')); ?>

        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>

<div class="card" id="relatorio-content">
    <div class="card-header">
        <i class="bi bi-cash-stack me-2"></i>
        Valores Executados por Escala - <?php echo e($mesesNomes[$mesInicio]); ?><?php if($mesInicio != $mesFim): ?> a <?php echo e($mesesNomes[$mesFim]); ?><?php endif; ?>/<?php echo e($ano); ?>

        <?php if($unidadeSelecionada): ?>
            - <?php echo e($unidadeSelecionada->nome); ?>

        <?php endif; ?>
    </div>
    <div class="card-body">
        <?php if($dados->isEmpty()): ?>
            <div class="text-center text-muted py-5">
                <i class="bi bi-inbox display-1"></i>
                <p class="mt-3">Nenhum dado encontrado para o período selecionado.</p>
            </div>
        <?php else: ?>
            <div class="table-responsive">
                <table class="table table-striped table-hover">
                    <thead class="table-dark">
                        <tr>
                            <th>#</th>
                            <th>Unidade</th>
                            <th>Mês/Ano</th>
                            <th class="text-center">Status</th>
                            <th class="text-end">Orçamento Previsto</th>
                            <th class="text-end">Valor Executado</th>
                            <th class="text-end">Diferença</th>
                            <th class="text-center">Total Horas</th>
                            <th class="text-center">Servidores</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                            $num = 1; 
                            $totalPrevisto = 0; 
                            $totalExecutado = 0; 
                            $totalHoras = 0;
                        ?>
                        <?php $__currentLoopData = $dados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php 
                                $totalPrevisto += $d->orcamento_previsto; 
                                $totalExecutado += $d->valor_executado;
                                $totalHoras += $d->total_horas;
                                $diferenca = $d->orcamento_previsto - $d->valor_executado;
                            ?>
                            <tr>
                                <td><?php echo e(str_pad($num++, 3, '0', STR_PAD_LEFT)); ?></td>
                                <td><?php echo e($d->unidade_nome); ?></td>
                                <td><?php echo e($mesesNomes[$d->mes]); ?>/<?php echo e($d->ano); ?></td>
                                <td class="text-center">
                                    <?php if($d->status == 'executada'): ?>
                                        <span class="badge bg-success">Executada</span>
                                    <?php elseif($d->status == 'aprovada'): ?>
                                        <span class="badge bg-primary">Aprovada</span>
                                    <?php else: ?>
                                        <span class="badge bg-secondary"><?php echo e(ucfirst($d->status)); ?></span>
                                    <?php endif; ?>
                                </td>
                                <td class="text-end">R$ <?php echo e(number_format($d->orcamento_previsto, 2, ',', '.')); ?></td>
                                <td class="text-end">
                                    <strong>R$ <?php echo e(number_format($d->valor_executado, 2, ',', '.')); ?></strong>
                                </td>
                                <td class="text-end">
                                    <?php if($diferenca >= 0): ?>
                                        <span class="text-success">R$ <?php echo e(number_format($diferenca, 2, ',', '.')); ?></span>
                                    <?php else: ?>
                                        <span class="text-danger">R$ <?php echo e(number_format($diferenca, 2, ',', '.')); ?></span>
                                    <?php endif; ?>
                                </td>
                                <td class="text-center"><?php echo e(number_format($d->total_horas, 0, ',', '.')); ?></td>
                                <td class="text-center"><?php echo e($d->total_servidores); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                    <tfoot class="table-secondary">
                        <tr class="fw-bold">
                            <td colspan="4" class="text-end">TOTAIS:</td>
                            <td class="text-end">R$ <?php echo e(number_format($totalPrevisto, 2, ',', '.')); ?></td>
                            <td class="text-end">R$ <?php echo e(number_format($totalExecutado, 2, ',', '.')); ?></td>
                            <td class="text-end">
                                <?php $diferencaTotal = $totalPrevisto - $totalExecutado; ?>
                                <?php if($diferencaTotal >= 0): ?>
                                    <span class="text-success">R$ <?php echo e(number_format($diferencaTotal, 2, ',', '.')); ?></span>
                                <?php else: ?>
                                    <span class="text-danger">R$ <?php echo e(number_format($diferencaTotal, 2, ',', '.')); ?></span>
                                <?php endif; ?>
                            </td>
                            <td class="text-center"><?php echo e(number_format($totalHoras, 0, ',', '.')); ?></td>
                            <td></td>
                        </tr>
                    </tfoot>
                </table>
            </div>
            
            <div class="row mt-4">
                <div class="col-md-3">
                    <div class="card bg-light">
                        <div class="card-body text-center">
                            <h6 class="text-muted">Total de Escalas</h6>
                            <h3 class="text-primary"><?php echo e($dados->count()); ?></h3>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card bg-light">
                        <div class="card-body text-center">
                            <h6 class="text-muted">Orçamento Previsto</h6>
                            <h3 class="text-info">R$ <?php echo e(number_format($totalPrevisto, 2, ',', '.')); ?></h3>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card bg-light">
                        <div class="card-body text-center">
                            <h6 class="text-muted">Valor Executado</h6>
                            <h3 class="text-success">R$ <?php echo e(number_format($totalExecutado, 2, ',', '.')); ?></h3>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card bg-light">
                        <div class="card-body text-center">
                            <h6 class="text-muted">Saldo</h6>
                            <h3 class="<?php echo e($diferencaTotal >= 0 ? 'text-success' : 'text-danger'); ?>">
                                R$ <?php echo e(number_format($diferencaTotal, 2, ',', '.')); ?>

                            </h3>
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>
</div>

<style>
@media print {
    @page {
        size: A4 landscape;
        margin: 10mm;
    }
    html, body {
        width: 100% !important;
        height: 100% !important;
        margin: 0 !important;
        padding: 0 !important;
        -webkit-print-color-adjust: exact !important;
        print-color-adjust: exact !important;
    }
    .sidebar, .navbar, form, .btn, .alert, .card:not(#relatorio-content), nav { 
        display: none !important; 
    }
    .main-content, .container-fluid, .row, .col-12, .col-md-10 {
        width: 100% !important;
        max-width: 100% !important;
        padding: 0 !important;
        margin: 0 !important;
    }
    #relatorio-content {
        width: 100% !important;
        border: none !important;
        box-shadow: none !important;
        margin: 0 !important;
    }
    #relatorio-content .card-header {
        background-color: #198754 !important;
        color: #fff !important;
        font-size: 14pt !important;
        padding: 10px !important;
    }
    #relatorio-content .card-body {
        padding: 10px 0 !important;
    }
    .table {
        width: 100% !important;
        font-size: 9pt !important;
    }
    .table th, .table td {
        padding: 5px 6px !important;
    }
    .table-dark th { 
        background-color: #198754 !important; 
        color: #fff !important; 
    }
    .table-secondary td {
        background-color: #e9ecef !important;
    }
    .badge { 
        border: 1px solid #000 !important;
        padding: 2px 6px !important;
    }
    .row.mt-4 {
        margin-top: 15px !important;
    }
    .row.mt-4 .card {
        display: inline-block !important;
        width: 23% !important;
        margin: 0 1% !important;
        border: 1px solid #ccc !important;
    }
}
</style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/runner/workspace/sigeex-laravel/resources/views/superintendente/relatorio-financeiro.blade.php ENDPATH**/ ?>