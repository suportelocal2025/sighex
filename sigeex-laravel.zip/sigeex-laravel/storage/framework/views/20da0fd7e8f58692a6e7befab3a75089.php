<?php $__env->startSection('title', 'Superintendente - Alertas'); ?>
<?php $__env->startSection('header', 'Central de Alertas'); ?>

<?php $__env->startSection('sidebar'); ?>
    <a href="/superintendente" class="nav-link"><i class="bi bi-speedometer2"></i> Dashboard</a>
    <a href="/superintendente/orcamento" class="nav-link"><i class="bi bi-wallet2"></i> Orçamento</a>
    <a href="/superintendente/distribuicao" class="nav-link"><i class="bi bi-diagram-3"></i> Distribuição</a>
    <a href="/superintendente/escalas" class="nav-link"><i class="bi bi-calendar-check"></i> Escalas</a>
    <a href="/superintendente/alertas" class="nav-link active"><i class="bi bi-bell"></i> Alertas</a>
    <a href="/superintendente/relatorios" class="nav-link"><i class="bi bi-file-earmark-bar-graph"></i> Relatórios</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row mb-4">
    <div class="col">
        <h2><i class="bi bi-bell me-2"></i>Central de Alertas</h2>
    </div>
</div>

<div class="card mb-4">
    <div class="card-body">
        <form method="GET" class="row g-3 align-items-end">
            <div class="col-md-2">
                <label class="form-label">Ano</label>
                <select name="ano" class="form-select">
                    <?php for($y = date('Y') - 2; $y <= date('Y') + 1; $y++): ?>
                        <option value="<?php echo e($y); ?>" <?php echo e($y == $ano ? 'selected' : ''); ?>><?php echo e($y); ?></option>
                    <?php endfor; ?>
                </select>
            </div>
            <div class="col-md-3">
                <label class="form-label">Mês</label>
                <select name="mes" class="form-select">
                    <option value="">Todos os meses</option>
                    <?php $nomesMeses = ['', 'Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho', 'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro']; ?>
                    <?php for($m = 1; $m <= 12; $m++): ?>
                        <option value="<?php echo e($m); ?>" <?php echo e($mes == $m ? 'selected' : ''); ?>><?php echo e($nomesMeses[$m]); ?></option>
                    <?php endfor; ?>
                </select>
            </div>
            <div class="col-md-3">
                <label class="form-label">Unidade</label>
                <select name="unidade_id" class="form-select">
                    <option value="">Todas as unidades</option>
                    <?php $__currentLoopData = $unidades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unidade): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($unidade->id); ?>" <?php echo e($unidadeId == $unidade->id ? 'selected' : ''); ?>><?php echo e($unidade->nome); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="col-md-2">
                <label class="form-label">Tipo</label>
                <select name="tipo" class="form-select">
                    <option value="">Todos</option>
                    <option value="vermelho" <?php echo e($tipo == 'vermelho' ? 'selected' : ''); ?>>Vermelho</option>
                    <option value="amarelo" <?php echo e($tipo == 'amarelo' ? 'selected' : ''); ?>>Amarelo</option>
                </select>
            </div>
            <div class="col-md-2">
                <button type="submit" class="btn btn-primary w-100">
                    <i class="bi bi-filter me-1"></i>Filtrar
                </button>
            </div>
        </form>
    </div>
</div>

<div class="row g-3 mb-4">
    <div class="col-md-4">
        <div class="card bg-danger text-white">
            <div class="card-body text-center">
                <h3><?php echo e(count($alertasVermelho)); ?></h3>
                <p class="mb-0">Alertas Vermelho</p>
                <small>Margem Excedida</small>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card bg-warning">
            <div class="card-body text-center">
                <h3><?php echo e(count($alertasAmarelo)); ?></h3>
                <p class="mb-0">Alertas Amarelo</p>
                <small>Acima do Previsto</small>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card bg-secondary text-white">
            <div class="card-body text-center">
                <h3><?php echo e(count($alertasVermelho) + count($alertasAmarelo)); ?></h3>
                <p class="mb-0">Total de Alertas</p>
                <small><?php echo e($ano); ?></small>
            </div>
        </div>
    </div>
</div>

<?php if(count($alertasVermelho) > 0): ?>
<div class="card mb-4 border-danger">
    <div class="card-header bg-danger text-white d-flex justify-content-between align-items-center">
        <h5 class="mb-0"><i class="bi bi-exclamation-octagon me-2"></i>Alertas Vermelho - Margem Excedida</h5>
        <form method="POST" action="/superintendente/enviar-alerta-email" class="d-inline">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="ano" value="<?php echo e($ano); ?>">
            <input type="hidden" name="tipo" value="vermelho">
            <button type="submit" class="btn btn-sm btn-light">
                <i class="bi bi-envelope me-1"></i>Enviar por Email
            </button>
        </form>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>Unidade</th>
                        <th>Mês</th>
                        <th>Limite c/ Margem</th>
                        <th>Gasto</th>
                        <th>Excedente</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $alertasVermelho; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alerta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><strong><?php echo e($alerta['unidade_nome']); ?></strong></td>
                        <td><?php echo e($alerta['mes_nome']); ?>/<?php echo e($ano); ?></td>
                        <td>R$ <?php echo e(number_format($alerta['limite'], 2, ',', '.')); ?></td>
                        <td class="text-danger fw-bold">R$ <?php echo e(number_format($alerta['gasto'], 2, ',', '.')); ?></td>
                        <td><span class="badge bg-danger">+R$ <?php echo e(number_format($alerta['excedente'], 2, ',', '.')); ?></span></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php endif; ?>

<?php if(count($alertasAmarelo) > 0): ?>
<div class="card mb-4 border-warning">
    <div class="card-header bg-warning d-flex justify-content-between align-items-center">
        <h5 class="mb-0"><i class="bi bi-exclamation-triangle me-2"></i>Alertas Amarelo - Acima do Previsto</h5>
        <form method="POST" action="/superintendente/enviar-alerta-email" class="d-inline">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="ano" value="<?php echo e($ano); ?>">
            <input type="hidden" name="tipo" value="amarelo">
            <button type="submit" class="btn btn-sm btn-dark">
                <i class="bi bi-envelope me-1"></i>Enviar por Email
            </button>
        </form>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>Unidade</th>
                        <th>Mês</th>
                        <th>Previsto</th>
                        <th>Gasto</th>
                        <th>Acima</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $alertasAmarelo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alerta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><strong><?php echo e($alerta['unidade_nome']); ?></strong></td>
                        <td><?php echo e($alerta['mes_nome']); ?>/<?php echo e($ano); ?></td>
                        <td>R$ <?php echo e(number_format($alerta['orcamento'], 2, ',', '.')); ?></td>
                        <td class="text-warning fw-bold">R$ <?php echo e(number_format($alerta['gasto'], 2, ',', '.')); ?></td>
                        <td><span class="badge bg-warning text-dark">+R$ <?php echo e(number_format($alerta['excedente'], 2, ',', '.')); ?></span></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php endif; ?>

<?php if(count($alertasVermelho) == 0 && count($alertasAmarelo) == 0): ?>
<div class="alert alert-success">
    <i class="bi bi-check-circle me-2"></i>Nenhum alerta encontrado para os filtros selecionados.
</div>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/runner/workspace/sigeex-laravel/resources/views/superintendente/alertas.blade.php ENDPATH**/ ?>