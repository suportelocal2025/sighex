<?php $__env->startSection('title', 'RH - Detalhar Escala'); ?>
<?php $__env->startSection('header', 'Detalhes da Escala'); ?>

<?php $__env->startSection('sidebar'); ?>
    <a href="/rh" class="nav-link"><i class="bi bi-speedometer2"></i> Dashboard</a>
    <a href="/rh/escalas" class="nav-link"><i class="bi bi-calendar-check"></i> Escalas</a>
    <a href="/rh/servidores" class="nav-link"><i class="bi bi-people"></i> Servidores</a>
    <a href="/rh/relatorios" class="nav-link"><i class="bi bi-file-earmark-bar-graph"></i> Relatórios</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php
    $meses = ['', 'Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho', 
              'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'];
    $totalHoras = $alocacoes->sum(fn($a) => $a->horas ?? 0);
    $totalAbono = $alocacoes->sum(fn($a) => $a->horas_abono ?? 0);
    $totalGeral = $totalHoras + $totalAbono;
?>

<div class="row mb-4">
    <div class="col-md-8">
        <div class="card p-3">
            <div class="row">
                <div class="col-md-4">
                    <small class="text-muted">Unidade</small>
                    <h5 class="mb-0"><?php echo e($escala->unidade->nome ?? 'N/A'); ?></h5>
                </div>
                <div class="col-md-4">
                    <small class="text-muted">Período</small>
                    <h5 class="mb-0"><?php echo e($meses[$escala->mes]); ?>/<?php echo e($escala->ano); ?></h5>
                </div>
                <div class="col-md-4">
                    <small class="text-muted">Total de Horas</small>
                    <h5 class="mb-0"><?php echo e(number_format($totalGeral, 0, ',', '.')); ?>h</h5>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card p-3 text-center">
            <?php
                $badgeClass = match($escala->status) {
                    'pendente' => 'bg-warning',
                    'aprovada' => 'bg-success',
                    'executada' => 'bg-info',
                    'rejeitada' => 'bg-danger',
                    default => 'bg-secondary'
                };
            ?>
            <span class="badge <?php echo e($badgeClass); ?> fs-5 py-2">
                <?php echo e(ucfirst($escala->status)); ?>

            </span>
        </div>
    </div>
</div>

<div class="row g-4 mb-4">
    <div class="col-md-6">
        <div class="card">
            <div class="card-header bg-white">
                <h5 class="mb-0"><i class="bi bi-person-badge me-2"></i>Resumo por Servidor</h5>
            </div>
            <div class="table-responsive">
                <table class="table table-sm">
                    <thead>
                        <tr>
                            <th>Servidor</th>
                            <th>Matrícula</th>
                            <th class="text-center">Horas</th>
                            <th class="text-center">Abono</th>
                            <th class="text-center">Total</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                            $resumo = $alocacoes->groupBy('servidor_id')->map(function($group) use ($servidores) {
                                $servidor = $servidores->firstWhere('servidor_id', $group->first()->servidor_id);
                                $horas = $group->sum(fn($a) => $a->horas ?? 0);
                                $abono = $group->sum(fn($a) => $a->horas_abono ?? 0);
                                return [
                                    'nome' => $servidor?->servidor?->nome ?? 'N/A',
                                    'matricula' => $servidor?->servidor?->matricula ?? '-',
                                    'horas' => $horas,
                                    'abono' => $abono,
                                    'total' => $horas + $abono,
                                ];
                            });
                        ?>
                        <?php $__currentLoopData = $resumo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($r['nome']); ?></td>
                            <td><?php echo e($r['matricula']); ?></td>
                            <td class="text-center"><?php echo e(number_format($r['horas'], 1)); ?></td>
                            <td class="text-center"><?php echo e(number_format($r['abono'], 1)); ?></td>
                            <td class="text-center fw-bold"><?php echo e(number_format($r['total'], 1)); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <div class="col-md-6">
        <div class="card h-100">
            <div class="card-header bg-white">
                <h5 class="mb-0"><i class="bi bi-info-circle me-2"></i>Informações</h5>
            </div>
            <div class="card-body">
                <table class="table table-borderless">
                    <tr>
                        <th>Data de Envio:</th>
                        <td><?php echo e($escala->data_envio ? date('d/m/Y H:i', strtotime($escala->data_envio)) : '-'); ?></td>
                    </tr>
                    <?php if($escala->data_aprovacao): ?>
                    <tr>
                        <th>Data de Aprovação:</th>
                        <td><?php echo e(date('d/m/Y H:i', strtotime($escala->data_aprovacao))); ?></td>
                    </tr>
                    <?php endif; ?>
                    <?php if($escala->status === 'executada' && $escala->valor_executado): ?>
                    <tr>
                        <th>Valor Executado:</th>
                        <td class="text-success fw-bold">R$ <?php echo e(number_format($escala->valor_executado, 2, ',', '.')); ?></td>
                    </tr>
                    <?php endif; ?>
                    <?php if($escala->motivo_rejeicao): ?>
                    <tr>
                        <th>Motivo da Rejeição:</th>
                        <td class="text-danger"><?php echo e($escala->motivo_rejeicao); ?></td>
                    </tr>
                    <?php endif; ?>
                </table>
            </div>
        </div>
    </div>
</div>

<?php if($escala->status === 'pendente'): ?>
<div class="row g-4 mb-4">
    <div class="col-md-6">
        <div class="card border-success">
            <div class="card-body">
                <h5 class="text-success"><i class="bi bi-check-circle"></i> Aprovar Escala</h5>
                <form method="POST" action="/rh/aprovar" onsubmit="return confirm('Confirma aprovação desta escala?')">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="escala_id" value="<?php echo e($escala->id); ?>">
                    <button type="submit" class="btn btn-success">Aprovar</button>
                </form>
            </div>
        </div>
    </div>
    <div class="col-md-6">
        <div class="card border-danger">
            <div class="card-body">
                <h5 class="text-danger"><i class="bi bi-x-circle"></i> Rejeitar Escala</h5>
                <form method="POST" action="/rh/rejeitar">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="escala_id" value="<?php echo e($escala->id); ?>">
                    <div class="mb-3">
                        <textarea name="motivo_rejeicao" class="form-control" rows="2" 
                                  placeholder="Informe o motivo da rejeição (mín. 10 caracteres)" required minlength="10"></textarea>
                    </div>
                    <button type="submit" class="btn btn-danger">Rejeitar</button>
                </form>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>

<?php if($escala->status === 'aprovada'): ?>
<div class="row g-4 mb-4">
    <div class="col-md-6">
        <div class="card border-info">
            <div class="card-body">
                <h5 class="text-info"><i class="bi bi-cash-stack"></i> Marcar como Executada</h5>
                <form method="POST" action="/rh/executar">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="escala_id" value="<?php echo e($escala->id); ?>">
                    <div class="mb-3">
                        <label class="form-label">Valor Executado (R$)</label>
                        <input type="number" name="valor_executado" class="form-control" step="0.01" min="0" required>
                    </div>
                    <button type="submit" class="btn btn-info">Marcar como Executada</button>
                </form>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>

<?php
    $alocacoesAgrupadas = [];
    foreach ($alocacoes as $a) {
        $servidor = $servidores->firstWhere('servidor_id', $a->servidor_id);
        $key = $a->servidor_id . '_' . ($a->equipe_id ?? 0) . '_' . ($a->modulo_id ?? 0);
        if (!isset($alocacoesAgrupadas[$key])) {
            $alocacoesAgrupadas[$key] = [
                'servidor_nome' => $servidor?->servidor?->nome ?? 'N/A',
                'matricula' => $servidor?->servidor?->matricula ?? '-',
                'equipe_nome' => $servidor?->equipe?->nome ?? '-',
                'modulo_nome' => $servidor?->modulo?->nome ?? '-',
                'is_lider' => $servidor?->lider ?? false,
                'dias' => [],
                'horas' => 0,
                'horas_abono' => 0
            ];
        }
        $alocacoesAgrupadas[$key]['dias'][] = str_pad($a->dia, 2, '0', STR_PAD_LEFT);
        $alocacoesAgrupadas[$key]['horas'] += $a->horas ?? 0;
        $alocacoesAgrupadas[$key]['horas_abono'] += $a->horas_abono ?? 0;
    }
    foreach ($alocacoesAgrupadas as &$ag) {
        sort($ag['dias']);
    }
    unset($ag);
?>

<div class="card">
    <div class="card-header bg-white d-flex justify-content-between align-items-center">
        <h5 class="mb-0"><i class="bi bi-table me-2"></i>Alocações Detalhadas</h5>
        <div>
            <a href="/rh/escala/<?php echo e($escala->id); ?>/exportar-excel" class="btn btn-success btn-sm me-2">
                <i class="bi bi-file-earmark-excel me-2"></i>Exportar Excel
            </a>
            <button class="btn btn-outline-primary btn-sm" onclick="window.print()">
                <i class="bi bi-printer me-2"></i>Imprimir
            </button>
        </div>
    </div>
    <div class="table-responsive">
        <table class="table table-hover">
            <thead>
                <tr>
                    <th>Servidor</th>
                    <th>Matrícula</th>
                    <th>Equipe</th>
                    <th>Módulo</th>
                    <th>Dias</th>
                    <th class="text-center">Horas</th>
                    <th class="text-center">Abono</th>
                    <th class="text-center">Líder</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $alocacoesAgrupadas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($a['servidor_nome']); ?></td>
                    <td><?php echo e($a['matricula']); ?></td>
                    <td><?php echo e($a['equipe_nome']); ?></td>
                    <td><?php echo e($a['modulo_nome']); ?></td>
                    <td><span class="badge bg-light text-dark"><?php echo e(implode(', ', $a['dias'])); ?></span></td>
                    <td class="text-center"><?php echo e(number_format($a['horas'], 1)); ?></td>
                    <td class="text-center"><?php echo e(number_format($a['horas_abono'], 1)); ?></td>
                    <td class="text-center">
                        <?php if($a['is_lider']): ?>
                            <span class="badge bg-warning"><i class="bi bi-star-fill"></i></span>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="8" class="text-center py-4 text-muted">
                        <i class="bi bi-calendar-x display-4"></i>
                        <p class="mt-2">Nenhuma alocação encontrada</p>
                    </td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<div class="mt-4">
    <a href="/rh/escalas" class="btn btn-outline-secondary">
        <i class="bi bi-arrow-left me-2"></i>Voltar
    </a>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/runner/workspace/sigeex-laravel/resources/views/rh/detalhar-escala.blade.php ENDPATH**/ ?>