<?php $__env->startSection('title', 'Superintendente - Dashboard'); ?>
<?php $__env->startSection('header', 'Dashboard do Superintendente'); ?>

<?php $__env->startSection('sidebar'); ?>
    <a href="/superintendente" class="nav-link active"><i class="bi bi-speedometer2"></i> Dashboard</a>
    <a href="/superintendente/orcamento" class="nav-link"><i class="bi bi-wallet2"></i> Orçamento</a>
    <a href="/superintendente/distribuicao" class="nav-link"><i class="bi bi-diagram-3"></i> Distribuição</a>
    <a href="/superintendente/escalas" class="nav-link"><i class="bi bi-calendar-check"></i> Escalas</a>
    <a href="/superintendente/alertas" class="nav-link"><i class="bi bi-bell"></i> Alertas 
        <?php $totalAlertas = count($alertasVermelho) + count($alertasAmarelo); ?>
        <?php if($totalAlertas > 0): ?><span class="badge bg-danger"><?php echo e($totalAlertas); ?></span><?php endif; ?>
    </a>
    <a href="/superintendente/relatorios" class="nav-link"><i class="bi bi-file-earmark-bar-graph"></i> Relatórios</a>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
<style>
.stat-card {
    padding: 1rem;
    border-radius: 8px;
    box-shadow: 0 1px 3px rgba(0,0,0,0.1);
}
.stat-icon {
    width: 48px;
    height: 48px;
    border-radius: 8px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1.25rem;
}
.stat-value {
    font-size: 1.1rem;
    font-weight: 700;
    color: #1a4480;
}
.stat-label {
    font-size: 0.75rem;
    color: #6b7280;
    text-transform: uppercase;
}
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<?php $totalAlertas = count($alertasVermelho) + count($alertasAmarelo); ?>
<div class="row g-3 mb-4">
    <div class="col-lg-3 col-md-6 col-sm-6">
        <a href="/superintendente/alertas" class="text-decoration-none">
            <div class="card h-100 <?php echo e($totalAlertas > 0 ? 'border-danger border-2' : ''); ?>">
                <div class="card-body p-3">
                    <div class="d-flex align-items-center justify-content-between">
                        <div class="d-flex align-items-center">
                            <div class="stat-icon bg-danger bg-opacity-10 me-3">
                                <i class="bi bi-bell text-danger"></i>
                            </div>
                            <div>
                                <div class="stat-label">Alertas</div>
                                <div class="stat-value"><?php echo e($totalAlertas); ?></div>
                            </div>
                        </div>
                        <div class="d-flex flex-column gap-1">
                            <?php if(count($alertasVermelho) > 0): ?>
                            <span class="badge bg-danger rounded-pill"><?php echo e(count($alertasVermelho)); ?> vermelho</span>
                            <?php endif; ?>
                            <?php if(count($alertasAmarelo) > 0): ?>
                            <span class="badge bg-warning text-dark rounded-pill"><?php echo e(count($alertasAmarelo)); ?> amarelo</span>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </a>
    </div>
</div>

<div class="row mb-4">
    <div class="col-12">
        <div class="card p-3">
            <div class="d-flex justify-content-between align-items-center flex-wrap gap-2">
                <div>
                    <label class="form-label mb-0 me-2">Filtrar por Ano:</label>
                    <select class="form-select form-select-sm d-inline-block w-auto" onchange="window.location.href='?ano='+this.value+'&periodo=<?php echo e($periodo); ?>'">
                        <?php for($y = date('Y') - 2; $y <= date('Y') + 1; $y++): ?>
                            <option value="<?php echo e($y); ?>" <?php echo e($y == $ano ? 'selected' : ''); ?>><?php echo e($y); ?></option>
                        <?php endfor; ?>
                    </select>
                </div>
                <div class="btn-group" role="group">
                    <button type="button" class="btn btn-sm <?php echo e($periodo == 'mes' ? 'btn-primary' : 'btn-outline-primary'); ?>" onclick="filtrarPeriodo('mes')">Mês</button>
                    <button type="button" class="btn btn-sm <?php echo e($periodo == 'trimestre' ? 'btn-primary' : 'btn-outline-primary'); ?>" onclick="filtrarPeriodo('trimestre')">Trimestre</button>
                    <button type="button" class="btn btn-sm <?php echo e($periodo == 'ano' ? 'btn-primary' : 'btn-outline-primary'); ?>" onclick="filtrarPeriodo('ano')">Ano</button>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="row g-4 mb-4">
    <div class="col-md-4 col-lg-2">
        <div class="card stat-card">
            <div class="d-flex align-items-center">
                <div class="stat-icon bg-primary bg-opacity-10 text-primary me-3">
                    <i class="bi bi-cash-stack"></i>
                </div>
                <div>
                    <div class="stat-value">R$ <?php echo e(number_format($orcamento?->valor_total ?? 0, 0, ',', '.')); ?></div>
                    <div class="stat-label">Orçamento Total</div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-4 col-lg-2">
        <div class="card stat-card">
            <div class="d-flex align-items-center">
                <div class="stat-icon bg-warning bg-opacity-10 text-warning me-3">
                    <i class="bi bi-piggy-bank"></i>
                </div>
                <div>
                    <div class="stat-value">R$ <?php echo e(number_format($reservaTecnica, 0, ',', '.')); ?></div>
                    <div class="stat-label">Reserva Técnica</div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-4 col-lg-2">
        <div class="card stat-card">
            <div class="d-flex align-items-center">
                <div class="stat-icon bg-success bg-opacity-10 text-success me-3">
                    <i class="bi bi-wallet2"></i>
                </div>
                <div>
                    <div class="stat-value">R$ <?php echo e(number_format($valorDisponivel, 0, ',', '.')); ?></div>
                    <div class="stat-label">Disponível</div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-4 col-lg-2">
        <div class="card stat-card">
            <div class="d-flex align-items-center">
                <div class="stat-icon bg-info bg-opacity-10 text-info me-3">
                    <i class="bi bi-arrow-down-up"></i>
                </div>
                <div>
                    <div class="stat-value">R$ <?php echo e(number_format($totalDistribuido, 0, ',', '.')); ?></div>
                    <div class="stat-label">Repassado</div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-4 col-lg-2">
        <div class="card stat-card">
            <div class="d-flex align-items-center">
                <div class="stat-icon bg-danger bg-opacity-10 text-danger me-3">
                    <i class="bi bi-graph-down"></i>
                </div>
                <div>
                    <div class="stat-value">R$ <?php echo e(number_format($totalGasto, 0, ',', '.')); ?></div>
                    <div class="stat-label">Gastos</div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-4 col-lg-2">
        <div class="card stat-card">
            <div class="d-flex align-items-center">
                <div class="stat-icon bg-secondary bg-opacity-10 text-secondary me-3">
                    <i class="bi bi-building"></i>
                </div>
                <div>
                    <div class="stat-value"><?php echo e($totalUnidades); ?></div>
                    <div class="stat-label">Unidades</div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="row g-4 mb-4">
    <div class="col-lg-8">
        <div class="card p-4 h-100">
            <h6 class="card-title mb-3"><i class="bi bi-bar-chart me-2"></i>Gastos x Horas por Unidade</h6>
            <canvas id="chartGastosHoras" height="180"></canvas>
        </div>
    </div>
    <div class="col-lg-4">
        <div class="card p-4 h-100 d-flex flex-column">
            <h6 class="card-title mb-3"><i class="bi bi-pie-chart me-2"></i>Distribuição de Gastos</h6>
            <div class="flex-grow-1 d-flex align-items-center justify-content-center" style="max-height: 220px;">
                <canvas id="chartDistribuicao"></canvas>
            </div>
        </div>
    </div>
</div>

<div class="card">
    <div class="card-header bg-white py-3">
        <h5 class="mb-0"><i class="bi bi-table me-2"></i>Status das Unidades</h5>
    </div>
    <div class="table-responsive">
        <table class="table table-hover mb-0">
            <thead>
                <tr>
                    <th>Unidade</th>
                    <th class="text-end">Repassado (R$)</th>
                    <th class="text-end">Gasto (R$)</th>
                    <th class="text-end">Horas</th>
                    <th class="text-end">Saldo (R$)</th>
                    <th class="text-center">Uso</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $unidadesStats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $saldo = $u->orcamento_distribuido - $u->gasto_total;
                        $percentual = $u->orcamento_distribuido > 0 ? ($u->gasto_total / $u->orcamento_distribuido) * 100 : 0;
                        $corBarra = $percentual > 80 ? 'danger' : ($percentual > 50 ? 'warning' : 'success');
                    ?>
                    <tr>
                        <td><strong><?php echo e($u->nome); ?></strong></td>
                        <td class="text-end">R$ <?php echo e(number_format($u->orcamento_distribuido, 2, ',', '.')); ?></td>
                        <td class="text-end">R$ <?php echo e(number_format($u->gasto_total, 2, ',', '.')); ?></td>
                        <td class="text-end"><?php echo e(number_format($u->horas_total, 0, ',', '.')); ?>h</td>
                        <td class="text-end <?php echo e($saldo < 0 ? 'text-danger' : 'text-success'); ?>">
                            R$ <?php echo e(number_format($saldo, 2, ',', '.')); ?>

                        </td>
                        <td style="width: 150px;">
                            <div class="progress" style="height: 20px;">
                                <div class="progress-bar bg-<?php echo e($corBarra); ?>" style="width: <?php echo e(min($percentual, 100)); ?>%">
                                    <?php echo e(number_format($percentual, 0)); ?>%
                                </div>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
function filtrarPeriodo(p) {
    const url = new URL(window.location.href);
    url.searchParams.set('periodo', p);
    window.location.href = url.toString();
}

document.addEventListener('DOMContentLoaded', function() {
    const unidades = <?php echo json_encode($unidadesStats->pluck('nome')); ?>;
    const gastos = <?php echo json_encode($unidadesStats->pluck('gasto_total')); ?>;
    const horas = <?php echo json_encode($unidadesStats->pluck('horas_total')); ?>;
    
    new Chart(document.getElementById('chartGastosHoras'), {
        type: 'bar',
        data: {
            labels: unidades,
            datasets: [
                {
                    label: 'Gasto (R$)',
                    data: gastos,
                    backgroundColor: 'rgba(26, 68, 128, 0.8)',
                    borderRadius: 5
                },
                {
                    label: 'Horas',
                    data: horas,
                    backgroundColor: 'rgba(0, 169, 28, 0.8)',
                    borderRadius: 5
                }
            ]
        },
        options: {
            responsive: true,
            plugins: {
                legend: { position: 'top' }
            },
            scales: {
                y: { beginAtZero: true }
            }
        }
    });
    
    const cores = ['#1a4480', '#005ea2', '#00a91c', '#ffbe2e', '#d54309', '#5c5c5c', '#8168b3', '#0076d6'];
    
    new Chart(document.getElementById('chartDistribuicao'), {
        type: 'doughnut',
        data: {
            labels: unidades,
            datasets: [{
                data: gastos,
                backgroundColor: cores.slice(0, unidades.length),
                borderWidth: 2,
                borderColor: '#fff'
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: { position: 'bottom', labels: { boxWidth: 12 } }
            }
        }
    });
});
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/runner/workspace/sigeex-laravel/resources/views/superintendente/dashboard.blade.php ENDPATH**/ ?>